import { controller } from "./Controller/hau_controller.js";

controller.init();
controller.showProductPage();
